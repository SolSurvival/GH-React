package interfaces;



public interface User {

	public Integer getId();
	public String getEmail();
	public void setEmail(String email);
	public String getFirstName();
	public void setFirstName(String firstName);
	public String getLastName();
	public void setLastName(String lastName);
	public Integer getAge();
	public void setAge(Integer age);
	public String getTelephone();
	public void setTelephone(String telephone);
	public String getPassword();
	public void setPassword(String password);
	
}
