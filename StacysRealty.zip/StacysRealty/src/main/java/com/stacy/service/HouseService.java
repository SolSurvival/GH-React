package com.stacy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stacy.entity.House;
import com.stacy.repository.HouseRepository;

@Service
public class HouseService {
	
	@Autowired
	private HouseRepository houseRepository;
	
	
	public void saveUser(House house) {
		houseRepository.save(house);
	}

	public House getHouseById(Integer houseId) {
		return houseRepository.findById(houseId).get();
	}
	
	
	
}
