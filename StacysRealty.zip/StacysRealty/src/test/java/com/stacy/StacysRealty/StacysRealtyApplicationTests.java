package com.stacy.StacysRealty;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StacysRealtyApplicationTests {

	@Test
	void contextLoads() {
	}

}
